import { createRoot } from 'react-dom/client';
import App from './App';
import './astro.css';
createRoot(document.getElementById('root')!).render(<App/>);
