/** Optional WebGL presentation pass. Every visible shape comes from simulation pixels. */
export class Presentation {
 canvas:HTMLCanvasElement;gl:WebGLRenderingContext;program:WebGLProgram;texture:WebGLTexture;
 constructor(){
  this.canvas=document.createElement('canvas');this.canvas.width=1224;this.canvas.height=768;
  const gl=this.canvas.getContext('webgl',{alpha:false,preserveDrawingBuffer:true,antialias:false});if(!gl)throw new Error('WebGL unavailable');this.gl=gl;
  const vs=`attribute vec2 a; varying vec2 uv;void main(){uv=vec2((a.x+1.)*.5,(1.-a.y)*.5);gl_Position=vec4(a,0.,1.);}`;
  const fs=`precision mediump float;varying vec2 uv;uniform sampler2D frame;uniform vec2 sourceSize;uniform float time;
   vec3 sampleAt(vec2 p){return texture2D(frame,p/sourceSize).rgb;}
   float rand(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}
   float filled(vec3 c){return smoothstep(.025,.12,max(max(c.r,c.g),c.b));}
   void main(){vec2 p=uv*vec2(612.,384.);vec3 bg=mix(vec3(.031,.048,.042),vec3(.050,.074,.063),uv.y);vec3 c=sampleAt(p);float mask=filled(c);
    vec3 top=sampleAt(p+vec2(0.,-1.2));vec3 left=sampleAt(p+vec2(-1.2,0.));vec3 right=sampleAt(p+vec2(1.2,0.));vec3 bottom=sampleAt(p+vec2(0.,1.2));
    float edge=clamp((filled(bottom)-filled(top))*.22+(filled(right)-filled(left))*.10,-.18,.28);
    float grain=(rand(floor(p*2.))-.5)*.045;
    bool blue=c.b>c.r*1.35&&c.g>c.r*1.12&&c.b>.12;
    bool green=c.g>c.r*1.12&&c.g>c.b*1.2&&c.g>.12;
    if(blue){float depth=0.;for(int i=1;i<=12;i++){vec3 up=sampleAt(p-vec2(0.,float(i)*2.));if(up.b>up.r*1.35&&up.g>up.r*1.12)depth+=1.;}
     float wave=sin(p.x*.11+time*.6)*sin(p.x*.036-time*.45);float ripple=pow(max(0.,sin(p.x*.07+sin(p.y*.21+time*.4)*1.7+time*.3)),10.);
     c*=mix(1.16,.61,depth/12.);c+=vec3(.04,.07,.085)*ripple*.45;c+=vec3(.22,.28,.25)*(1.-depth/12.)*(.6+.25*wave);c+=grain*.25;
    }else if(green){c*=.8+rand(floor(p/2.))*.27;c+=edge*.65+grain;c.r+=.015;}
    else{float hot=step(c.g*1.65,c.r)*step(.5,c.r);c+=mix(grain,0.,hot);c+=edge*.3;}
    c=mix(bg,c,mask);float vignette=1.-.13*pow(length((uv-.5)*1.25),2.);c*=vignette;
    if(p.x<4.||p.x>608.||p.y<4.||p.y>380.)c=bg;
    gl_FragColor=vec4(c,1.);}`;
  const compile=(type:number,src:string)=>{const shader=gl.createShader(type)!;gl.shaderSource(shader,src);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(shader)||'Shader error');return shader;};
  this.program=gl.createProgram()!;gl.attachShader(this.program,compile(gl.VERTEX_SHADER,vs));gl.attachShader(this.program,compile(gl.FRAGMENT_SHADER,fs));gl.linkProgram(this.program);if(!gl.getProgramParameter(this.program,gl.LINK_STATUS))throw new Error('Renderer unavailable');gl.useProgram(this.program);
  const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);const a=gl.getAttribLocation(this.program,'a');gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,2,gl.FLOAT,false,0,0);
  this.texture=gl.createTexture()!;gl.bindTexture(gl.TEXTURE_2D,this.texture);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
 }
 draw(source:HTMLCanvasElement,time:number){const gl=this.gl;gl.useProgram(this.program);gl.bindTexture(gl.TEXTURE_2D,this.texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,source);gl.uniform2f(gl.getUniformLocation(this.program,'sourceSize'),source.width,source.height);gl.uniform1f(gl.getUniformLocation(this.program,'time'),time/1000);gl.viewport(0,0,1224,768);gl.drawArrays(gl.TRIANGLE_STRIP,0,4);return this.canvas;}
 destroy(){this.gl.deleteTexture(this.texture);this.gl.deleteProgram(this.program);this.gl.getExtension('WEBGL_lose_context')?.loseContext();}
}
