import { Presentation } from './presentation';
import { ensureIsolation } from './isolation';
export type BrushTool = 'brush'|'erase'|'line'|'box'|'fill'|'sample'|'heat'|'cool';
export type Material = {id:number;code:string;name:string;description:string;color:string;category:string;state:string;temperature:number;visible:boolean;wall?:boolean};
export type Stats = {count:number;fps:number;temperature:number;pressure:number;hover:string;paused:boolean;version:string};
type FS = {writeFile:(p:string,v:string|Uint8Array)=>void;readFile:(p:string,options?:{encoding:string})=>any;unlink:(p:string)=>void;analyzePath:(p:string)=>{exists:boolean};};
type Callbacks={onReady:(m:Material[])=>void;onStatus:(s:string)=>void;onError:(s:string)=>void;onStats:(s:Stats)=>void;onMessage:(s:string)=>void};
const names:Record<string,string>={DUST:'Dust',WATR:'Water',OIL:'Oil',FIRE:'Fire',STNE:'Stone',LAVA:'Lava',GUNP:'Gunpowder',NITR:'Nitroglycerin',CLNE:'Clone',GAS:'Gas',PLEX:'Plastic explosive',GOO:'Goo',ICE:'Ice',ICEI:'Ice',METL:'Metal',SPRK:'Spark',SNOW:'Snow',WOOD:'Wood',NEUT:'Neutron',PLUT:'Plutonium',PLNT:'Plant',ACID:'Acid',VOID:'Void',WTRV:'Steam',CNCT:'Concrete',DSTW:'Distilled water',SALT:'Salt',SLTW:'Salt water',DMND:'Diamond',BMTL:'Breakable metal',BRMT:'Broken metal',PHOT:'Photon',URAN:'Uranium',WAX:'Wax',MWAX:'Molten wax',PSCN:'P-type silicon',NSCN:'N-type silicon',LN2:'Liquid nitrogen',LNTG:'Liquid nitrogen',INSL:'Insulator',BHOL:'Black hole',WHOL:'White hole',RBDM:'Rubidium',LRBD:'Liquid rubidium',NTCT:'NTC thermistor',SAND:'Sand',GLAS:'Glass',PTCT:'PTC thermistor',BGLA:'Broken glass',THDR:'Thunder',PLSM:'Plasma',ETRD:'Electrode',NICE:'Nitrogen ice',NBLE:'Noble gas',BTRY:'Battery',LCRY:'Liquid crystal',STKM:'Stickman',SWCH:'Switch',SMKE:'Smoke',DESL:'Diesel',COAL:'Coal',LO2:'Liquid oxygen',LOXY:'Liquid oxygen',O2:'Oxygen',OXYG:'Oxygen',INWR:'Insulated wire',YEST:'Yeast',DYST:'Dead yeast',THRM:'Thermite',GLOW:'Glow',BRCK:'Brick',CFLM:'Cold flame',FIRW:'Firework',FUSE:'Fuse',FSEP:'Fuse powder',AMTR:'Antimatter',BCOL:'Broken coal',PCLN:'Powered clone',HSWC:'Heat switch',IRON:'Iron',MORT:'Mortar',LIFE:'Life',DLAY:'Delay',CO2:'Carbon dioxide',CO2G:'Carbon dioxide',DRIC:'Dry ice',CBNW:'Carbonated water',STOR:'Storage',CONV:'Converter',BOMB:'Bomb',C5:'C5 explosive',SING:'Singularity',QRTZ:'Quartz',PQRT:'Powdered quartz',EMP:'EMP',BREL:'Broken electronics',ELEC:'Electron',ACEL:'Accelerator',DCEL:'Decelerator',BANG:'Bang',IGNT:'Igniter',BOYL:'Boyle gas',GEL:'Gel',SOAP:'Soap',FILT:'Filter',FWRK:'Fireworks',FWRK2:'Fireworks',VINE:'Vine',SPNG:'Sponge',SAWD:'Sawdust',SEED:'Seed',BASE:'Base',ROCK:'Rock',LDTC:'Linear detector',PSTN:'Piston',FRME:'Frame',TUNG:'Tungsten',VIBR:'Vibranium',BVBR:'Broken vibranium',CRMC:'Ceramic',LITH:'Lithium',PTNM:'Platinum',SLCN:'Silicon',RSST:'Resist',RSSS:'Solid resist',RSSL:'Liquid resist',RSSG:'Resist gas',WIFI:'Wireless',ARAY:'Array',BRAY:'Beam',CRAY:'Creator ray',DRAY:'Duplicator ray',TSNS:'Temperature sensor',PSNS:'Pressure sensor',LSNS:'Life sensor',DTEC:'Detector',WIND:'Wind',HYGN:'Hydrogen',MERC:'Mercury',BIZR:'Bizarre',BIZRG:'Bizarre gas',BIZRS:'Bizarre solid',RIME:'Rime',FOG:'Fog',FLSH:'Flesh',BLOD:'Blood',PROT:'Proton',GRVT:'Graviton',DMG:'Damage',FILL:'Filler',HEAC:'Heat conductor',HEAT:'Heat',COOL:'Cool',VACU:'Vacuum',PUMP:'Pump',GPMP:'Gravity pump',PIPE:'Pipe',PPIP:'Powered pipe',PRTI:'Portal in',PRTO:'Portal out',STK2:'Stickman 2',FIGH:'Fighter',LOVE:'Love',LOLZ:'Lolz',TRON:'Tron',REPL:'Replicator',EXOT:'Exotic matter',BCLN:'Breakable clone',PBCN:'Powered B. clone',GBMB:'Gravity bomb',DEST:'Destroyer',ANAR:'Anti-air',C4:'C4 explosive'};
Object.assign(names,{'TNT':'TNT','BIZG':'Bizarre gas','BIZS':'Bizarre solid','C-5':'Cold explosive',CAUS:'Caustic gas',BUBW:'Carbonated water',CLST:'Clay dust',DEUT:'Deuterium oxide',EMBR:'Ember',EQVE:'Equal velocity',FRAY:'Force emitter',FRZW:'Freeze water',FRZZ:'Freeze powder',GOLD:'Gold',GRAV:'Gravity dust',GUN:'Gunpowder',IGNC:'Ignition cord',INST:'Instant conductor',INVS:'Invisible',ISOZ:'Isotope-Z',ISZS:'Solid isotope-Z',LIGH:'Lightning','C-4':'C4 explosive',POLO:'Polonium',PSTE:'Paste',PSTS:'Solid paste',PVOD:'Powered void',RFGL:'Liquid refrigerant',RFRG:'Refrigerant',RPEL:'Repeller',SHLD:'Shield',SHD2:'Shield II',SHD3:'Shield III',SHD4:'Shield IV',SPWN:'Spawn point',SPWN2:'Spawn point 2',TESC:'Tesla coil',TTAN:'Titanium',VIRS:'Virus',VRSG:'Gas virus',VRSS:'Solid virus',VSNS:'Velocity sensor',WARP:'Warp',VENT:'Air vent',WWLD:'Wireworld',GOL:'Game of Life',HLIF:'High Life',ASIM:'Assimilation','2X2':'2 × 2',DANI:'Day & Night',AMOE:'Amoeba',MOVE:'Move',PGOL:'Pseudo Life',DMOE:'Diamoeba','3-4':'3–4',LLIF:'Long Life',STAN:'Stains',SEEDL:'Life seeds',MAZE:'Maze',COAG:'Coagulations',WALLL:'Walled cities',GNAR:'Gnarl',MYST:'Mystery',LOTE:'Living on edge',FRG2:'Frogs II',STAR:'Star Wars',FROG:'Frogs',BRAN:'Brian 6'});
export class Engine {
 presentation:Presentation|null=null;
 canvas:HTMLCanvasElement; callbacks:Callbacks; source:HTMLCanvasElement|null=null; fs:FS|null=null; module:any; materials:Material[]=[]; config={material:'SAND',tool:'brush' as BrushTool,size:8,view:'smooth'}; queue:{id:number;code:string;resolve:(r:any)=>void;reject:(e:Error)=>void;time:number}[]=[]; active:typeof this.queue[number]|null=null; sequence=0; raf=0; stopped=false; ready=false; disposed=false; pointer={x:300,y:180,down:false,sx:0,sy:0}; frameCount=0; fps=0; lastTime=0; lastStats=0; version=''; initializedAt=0;
 constructor(canvas:HTMLCanvasElement,callbacks:Callbacks){this.canvas=canvas;this.callbacks=callbacks;try{this.presentation=new Presentation();}catch{ /* Canvas smoothing remains available. */ }}
 async start(){try{
  if(!await ensureIsolation(this.callbacks.onStatus))return;
  this.initializedAt=performance.now();
  const bridge=await fetch('/engine/bridge.lua').then(r=>{if(!r.ok)throw new Error('The simulation files could not be loaded.');return r.text();});
  if(this.disposed)return;
  if(!(window as any).create_powder) await new Promise<void>((resolve,reject)=>{const s=document.createElement('script');s.src='/engine/powder.js';s.onload=()=>resolve();s.onerror=()=>reject(new Error('The physics engine could not be downloaded.'));document.head.appendChild(s);});
  if(this.disposed)return;
  const src=document.createElement('canvas');src.id='canvas';src.className='engine-source';src.width=629;src.height=424;src.tabIndex=-1;src.setAttribute('aria-hidden','true');document.body.appendChild(src);this.source=src;
  (window as any).mark_presentable=()=>{};
  this.module=await (window as any).create_powder({canvas:src,arguments:['scale:1','disable-network'],locateFile:(name:string)=>'/engine/'+name,
   astroBoot:(fs:FS)=>{this.fs=fs;fs.writeFile('/powder/autorun.lua',bridge);fs.writeFile('/powder/powder.pref',JSON.stringify({Scale:1,Resizable:false,Fullscreen:false,Intro:false,ShowAvatars:false,Renderer:{DisplayModes:[],RenderModes:[]}}));},
   print:(s:string)=>{if(s.includes('Error'))console.warn(s);},printErr:(s:string)=>console.warn('[Powder Toy]',s),onAbort:()=>this.callbacks.onError('The physics engine stopped. Reload the page to start again.'),
   postMainLoop:()=>this.render(),
  });
  if(this.disposed){this.module?.pauseMainLoop?.();return;}
  this.lastTime=performance.now();this.loop();
 }catch(error){this.callbacks.onError(error instanceof Error?error.message:'The physics engine could not start.');}}
 private read(path:string){if(!this.fs?.analyzePath(path).exists)return null;return this.fs.readFile(path,{encoding:'utf8'});}
 loop=()=>{if(this.disposed)return;const now=performance.now();
  if(!this.ready){if(this.read('/tmp/astro-failure'))this.callbacks.onError(this.read('/tmp/astro-failure'));if(this.read('/tmp/astro-ready')){
   const raw=JSON.parse(this.read('/tmp/astro-catalog')||'[]');
   this.materials=raw.map((m:Material)=>({...m,name:m.name||names[m.code]||m.code})).sort((a:Material,b:Material)=>a.name.localeCompare(b.name));
   const v=JSON.parse(this.read('/tmp/astro-version')||'{}');this.version=`${v.major||''}.${v.minor||''}`;this.ready=true;this.callbacks.onReady(this.materials);
  }else if(now-this.initializedAt>30000){this.callbacks.onError('The engine is taking too long to initialize. Reload the page to try again.');}}
  if(this.ready&&this.fs){
   const runtimeError=this.read('/tmp/astro-runtime-failure');if(runtimeError){console.error('Astropowder bridge:',runtimeError);this.callbacks.onMessage(runtimeError);this.fs.unlink('/tmp/astro-runtime-failure');}
   if(this.active){const path='/tmp/astro-reply-'+this.active.id;const reply=this.read(path);if(reply){this.fs.unlink(path);const r=JSON.parse(reply);r.ok?this.active.resolve(r.value):this.active.reject(new Error(r.value));this.active=null;}else if(now-this.active.time>15000){this.active.reject(new Error('The simulation did not respond. Please reload.'));this.active=null;}}
   if(!this.active&&this.queue.length){this.active=this.queue.shift()!;this.active.time=now;this.fs.writeFile('/tmp/astro-command',this.active.id+'\n'+this.active.code);}
   if(now-this.lastStats>300){const raw=this.read('/tmp/astro-stats');if(raw){this.callbacks.onStats({...JSON.parse(raw),fps:this.fps,version:this.version});}this.lastStats=now;}
  }
  this.raf=requestAnimationFrame(this.loop);
 };
 render(){if(this.disposed||!this.source)return;const ctx=this.canvas.getContext('2d',{alpha:false});if(!ctx)return;const s=this.source;const factor=s.width/629;ctx.fillStyle='#0b110e';ctx.fillRect(0,0,this.canvas.width,this.canvas.height);ctx.imageSmoothingEnabled=this.config.view!=='classic';ctx.imageSmoothingQuality='high';ctx.globalCompositeOperation='screen';ctx.filter=this.config.view==='smooth'?'blur(0.45px) saturate(0.86)':'none';ctx.drawImage(s,0,0,612*factor,384*factor,0,0,this.canvas.width,this.canvas.height);ctx.filter='none';ctx.globalCompositeOperation='source-over';
  if(this.presentation&&this.config.view==='smooth'){ctx.drawImage(this.presentation.draw(s,performance.now()),0,0);}
  if(this.pointer.down&&(this.config.tool==='line'||this.config.tool==='box')){const p=this.pointer;ctx.strokeStyle='#c9ed96';ctx.lineWidth=2;ctx.setLineDash([5,5]);if(this.config.tool==='box')ctx.strokeRect(p.sx*2,p.sy*2,(p.x-p.sx)*2,(p.y-p.sy)*2);else{ctx.beginPath();ctx.moveTo(p.sx*2,p.sy*2);ctx.lineTo(p.x*2,p.y*2);ctx.stroke();}ctx.setLineDash([]);}
  const t=performance.now();this.frameCount++;if(t-this.lastTime>=1000){this.fps=this.frameCount*1000/(t-this.lastTime);this.frameCount=0;this.lastTime=t;}
 }
 command(code:string):Promise<any>{if(!this.ready)return Promise.reject(new Error('The simulation is still loading.'));const p=new Promise((resolve,reject)=>this.queue.push({id:++this.sequence,code,resolve,reject,time:0}));p.catch(e=>this.callbacks.onMessage(e.message));return p;}
 configure(c:Partial<typeof this.config>){const prev=this.config.view;this.config={...this.config,...c};if(this.ready&&c.view&&prev!==c.view){const views:Record<string,string>={smooth:'ren.colorMode(0);ren.displayMode(0)',classic:'ren.colorMode(0);ren.displayMode(0)',heat:'ren.colorMode(ren.COLOUR_HEAT);ren.displayMode(0)',pressure:'ren.colorMode(0);ren.displayMode(ren.DISPLAY_AIRP)',velocity:'ren.colorMode(0);ren.displayMode(ren.DISPLAY_AIRV)',life:'ren.colorMode(ren.COLOUR_LIFE);ren.displayMode(0)'};void this.command(views[c.view]);}}
 pointerDown(x:number,y:number,erase:boolean){if(!this.ready)return;this.pointer={x,y,down:true,sx:x,sy:y};const m=this.materials.find(m=>m.code===this.config.material);this.pointerMove(x,y);void this.command(`astroBegin(${x},${y},'${this.config.tool}',${this.config.size},${m?.id||0},${erase},${!!m?.wall})`);}
 pointerMove(x:number,y:number){this.pointer.x=x;this.pointer.y=y;if(this.ready)this.fs?.writeFile('/tmp/astro-pointer',`${x},${y}`);}
 pointerUp(){if(!this.pointer.down)return;this.pointer.down=false;if(this.ready)void this.command(`astro.x=${this.pointer.x};astro.y=${this.pointer.y};astroEnd()`);}
 sample(x:number,y:number){return this.command(`return astroSample(${x},${y})`);}
 pause(p:boolean){return this.command(`sim.paused(${p})`);}
 step(){return this.command('sim.paused(true);sim.frameRender(1)');}
 clear(){return this.command('sim.takeSnapshot();sim.clearSim();astro.down=false');}
 preset(id:string){if(!['terrarium','volcano','circuit','alchemy'].includes(id))return;return this.command(`return astroPreset('${id}')`);}
 setSpeed(speed:number){if([.25,.5,1,2].includes(speed))void this.command(`tpt.fpsCap(${60*speed})`);}
 setGravity(g:string){void this.command(`sim.gravityMode(${g==='off'?1:g==='radial'?2:0})`);}
 playerKey(key:string,down:boolean){
  const keys:Record<string,[string,number]>={ArrowLeft:['ArrowLeft',37],ArrowUp:['ArrowUp',38],ArrowRight:['ArrowRight',39],ArrowDown:['ArrowDown',40],w:['KeyW',87],a:['KeyA',65],s:['KeyS',83],d:['KeyD',68]};
  const k=keys[key];if(!this.ready||!this.source||!k)return false;
  this.source.dispatchEvent(new KeyboardEvent(down?'keydown':'keyup',{key,code:k[0],keyCode:k[1],which:k[1],bubbles:false,cancelable:true}));return true;
 }
 async save(name:string){await this.command('return astroSave()');const bytes=this.fs!.readFile('/tmp/astro-save') as Uint8Array;const blob=new Blob([new Uint8Array(bytes)],{type:'application/octet-stream'});this.download(blob,name+'.cps');try{let text='';for(const v of bytes)text+=String.fromCharCode(v);localStorage.setItem('astropowder-save',btoa(text));}catch{this.callbacks.onMessage('Downloaded successfully. Device storage is full or unavailable.');}}
 async load(file:File){if(file.size>16*1024*1024)throw new Error('Please open a save smaller than 16 MB.');const bytes=new Uint8Array(await file.arrayBuffer());if(bytes.length<12||!['OPS','PSv','fuC'].includes(String.fromCharCode(...bytes.slice(0,3))))throw new Error('This is not a Powder Toy save. Choose a .cps or .stm file.');this.fs?.writeFile('/tmp/astro-import',bytes);await this.command('return astroLoad()');}
 async restoreLocal(){const saved=localStorage.getItem('astropowder-save');if(!saved)return false;const bytes=Uint8Array.from(atob(saved),v=>v.charCodeAt(0));await this.load(new File([bytes],'Restored experiment.cps'));return true;}
 screenshot(name:string){this.canvas.toBlob(blob=>{if(blob)this.download(blob,name+'.png');},'image/png');}
 private download(blob:Blob,name:string){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name.replace(/[<>:"/\\|?*]/g,'-');a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);}
 destroy(){this.disposed=true;cancelAnimationFrame(this.raf);this.module?.pauseMainLoop?.();this.presentation?.destroy();this.source?.remove();for(const q of this.queue)q.reject(new Error('Simulation closed'));this.queue=[];}
}
