/** Some static hosts do not apply _headers. Isolate with a pass-through worker. */
export async function ensureIsolation(status:(s:string)=>void){
 if(window.crossOriginIsolated){sessionStorage.removeItem('astro-isolation-reload');return true;}
 if(!('serviceWorker' in navigator))throw new Error('This browser does not support the features needed for the physics engine. Try a current desktop browser.');
 status('Preparing the physics engine…');
 await navigator.serviceWorker.register('/isolation-worker.js',{scope:'/',updateViaCache:'none'});
 await navigator.serviceWorker.ready;
 if(!navigator.serviceWorker.controller){
  await new Promise<void>((resolve,reject)=>{
   const done=()=>{clearTimeout(timeout);navigator.serviceWorker.removeEventListener('controllerchange',done);resolve();};
   const timeout=setTimeout(()=>{navigator.serviceWorker.removeEventListener('controllerchange',done);reject(new Error('The browser could not initialize the simulation. Please reload.'));},12000);
   navigator.serviceWorker.addEventListener('controllerchange',done);
   if(navigator.serviceWorker.controller)done();
  });
 }
 const previous=Number(sessionStorage.getItem('astro-isolation-reload')||0);
 if(Date.now()-previous<20000)throw new Error('This browser view cannot start the physics engine. Open this page directly in a current browser.');
 sessionStorage.setItem('astro-isolation-reload',String(Date.now()));
 location.reload();return false;
}
