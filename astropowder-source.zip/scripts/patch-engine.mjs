import { readFileSync, writeFileSync } from 'node:fs';
const path = 'public/engine/powder.js';
let source = readFileSync(path, 'utf8');
if (!source.includes('ASTROPOWDER BRIDGE')) {
  source = source.replace('FS.syncfs(true, () => {\n      Module.ccall("MainJs"', 'FS.syncfs(true, () => {\n      // ASTROPOWDER BRIDGE: initialize the app Lua bridge after persisted files load.\n      Module.astroBoot?.(FS);\n      Module.ccall("MainJs"');
  source = source.replace('var registerKeyEventCallback = (target, userData, useCapture, callbackfunc, eventTypeId, eventTypeString, targetThread) => {', 'var registerKeyEventCallback = (target, userData, useCapture, callbackfunc, eventTypeId, eventTypeString, targetThread) => {\n  if (Module.astroBoot) target = "#canvas"; // Keep native shortcuts out of app inputs.');
  // Preserve the WebGL frame for the independently styled presentation canvas.
  source = source.replace('createContext: (/** @type {HTMLCanvasElement} */ canvas, webGLContextAttributes) => {', 'createContext: (/** @type {HTMLCanvasElement} */ canvas, webGLContextAttributes) => {\n    if (Module.astroBoot) webGLContextAttributes.preserveDrawingBuffer = true;');
  writeFileSync(path, source);
}
if(!source.includes('webGLContextAttributes.preserveDrawingBuffer = true')) {
 source=source.replace('createContext: (/** @type {HTMLCanvasElement} */ canvas, webGLContextAttributes) => {','createContext: (/** @type {HTMLCanvasElement} */ canvas, webGLContextAttributes) => {\n    if (Module.astroBoot) webGLContextAttributes.preserveDrawingBuffer = true;');
 writeFileSync(path,source);
}
source=source.replace('return document.title = UTF8ToString(title);','if (!Module.astroBoot) return document.title = UTF8ToString(title);');
writeFileSync(path,source);
