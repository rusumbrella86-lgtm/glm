# Astro Powder — Lounge integration

GPL-3.0. Built from the Astro Powder project created September 7–8, 2026.
Requires Node.js 22.13+: run `npm ci`, then `npm run dev` or `npm run build`.
The engine binary and bridge are unchanged. Integration adjusts imports, fonts, development detection, and the link back to The Lounge.
See public/engine/source-info.txt for engine credits and reproducible source.
Serve dist with the isolation headers in public/_headers.
